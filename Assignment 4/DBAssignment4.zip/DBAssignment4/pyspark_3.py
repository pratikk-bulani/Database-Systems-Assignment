import Init
from pyspark import SparkContext

index_latitude = Init.list_schema.index("latitude")
index_longitude = Init.list_schema.index("longitude")
sc = SparkContext("local", "Problem 3") # SparkContext creation
table_rdd = sc.parallelize(Init.list_table, numSlices=int(Init.sys.argv[1])).filter(lambda x: float(x[index_latitude]) >= 10 and float(x[index_latitude]) <= 90 and float(x[index_longitude]) >= -90 and float(x[index_longitude]) <= -10) # rdd creation
# table_rdd.saveAsTextFile(Init.sys.argv[2]) # not working as problem of winutils.exe

file_result = open(Init.sys.argv[2], "w", encoding="utf8")
for x in table_rdd.collect():
    file_result.write(",".join(x) + "\n")
file_result.close()