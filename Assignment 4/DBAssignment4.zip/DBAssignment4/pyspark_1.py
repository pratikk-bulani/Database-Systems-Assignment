import Init
from pyspark import SparkContext
from operator import add

index_country = Init.list_schema.index("country")
sc = SparkContext("local", "Problem 1") # SparkContext creation

table_rdd = sc.parallelize([(Init.list_table[i][index_country], 1) for i in range(len(Init.list_table))], numSlices=int(Init.sys.argv[1])).reduceByKey(add) # rdd creation
print(Init.sys.argv[2])
# table_rdd.saveAsTextFile(Init.sys.argv[2]) # not working as problem of winutils.exe

file_result = open(Init.sys.argv[2], "w", encoding="utf8")
for country, no_of_airports in table_rdd.collect():
    file_result.write(country+","+str(no_of_airports)+"\n")
file_result.close()