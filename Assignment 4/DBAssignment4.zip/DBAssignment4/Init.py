import re
import sys

str_data_file_path = "airports.csv"; file_data = open(str_data_file_path, "r", encoding="utf8") # open the data file

list_table = [] # this will hold all the rows
list_schema = file_data.readline().replace("\"","").replace("\n","").replace("\'","").lower().split(",") # this list holds the column name
regex_line_pattern = "^" + ("\s*\"(.*)\"\s*," * len(list_schema))[:-1] + r"\n$" # this will hold the regex pattern of each line of data

while True:
    line = file_data.readline()
    matched_pattern = re.match(regex_line_pattern, line)
    if matched_pattern is None: break
    list_table.append(matched_pattern.groups())
file_data.close()

if len(sys.argv) != 3: raise Exception("Error: Invalid number of command line arguments. The arguments are: number_of_cpus, output_file")