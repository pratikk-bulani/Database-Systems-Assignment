from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 9").master("local[*]").getOrCreate()

py_number_list = [1,2,3,4,5, 3, 1, 2]
number_rdd = spark.sparkContext.parallelize(py_number_list, 3)

print(number_rdd.distinct().collect())