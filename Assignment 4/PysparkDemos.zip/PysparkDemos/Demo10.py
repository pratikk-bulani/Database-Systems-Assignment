from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 10").master("local[*]").getOrCreate()

py_number_list = [1, 2, 3, 4, 5, 3, 1, 2]
number_rdd = spark.sparkContext.parallelize(py_number_list, 3)

print(number_rdd.map(lambda n: (n, 1)).groupByKey().collect()) # here 0th index (key) is the original element and 1st index (value) is the element 1
print(number_rdd.map(lambda n: (n, 1)).groupByKey().map(lambda x: (x[0], len(x[1]))).collect()) # x[0] is the key and x[1] is the list of elements belonging to that group

# note that groupByKey is performed at all the partitions simultaneously
# reduceByKey is used to perform groups on individual partitions initially and then the result of the groups are combined