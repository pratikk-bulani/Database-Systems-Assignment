from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 3").master("local[*]").getOrCreate()

py_number_list = [1,2,3,4,5]
number_rdd = spark.sparkContext.parallelize(py_number_list, 3)

print(number_rdd.filter(lambda n: n % 2 == 0).collect())

py_str_list = ["Arun", "Arvind", "Arjun", "Anna"]
str_rdd = spark.sparkContext.parallelize(py_str_list, 2)

print(str_rdd.filter(lambda name: 'r' in name).collect())