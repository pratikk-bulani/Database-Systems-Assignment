from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 4").master("local[*]").getOrCreate()

py_number_list = [1,2,3,4,5]
number_rdd = spark.sparkContext.parallelize(py_number_list, 3)

print(number_rdd.map(lambda n: n*n).collect())

py_str_list = ["Arun", "Arvind", "Arjun", "Anna"]
str_rdd = spark.sparkContext.parallelize(py_str_list, 2)

print(str_rdd.map(lambda name: name.upper()).collect())