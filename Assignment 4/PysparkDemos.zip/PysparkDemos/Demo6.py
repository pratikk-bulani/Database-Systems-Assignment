from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 6").master("local[*]").getOrCreate()

def findSum(partition):
    yield sum(partition)
def findSumIndex(index, partition):
    yield str(index) + ": " + str(sum(partition))

py_number_list = [1,2,1,1,2,1,1,2,3]
number_rdd = spark.sparkContext.parallelize(py_number_list, 3)
print(number_rdd.getNumPartitions())
print(number_rdd.mapPartitions(findSum).collect())
print(number_rdd.mapPartitionsWithIndex(findSumIndex).collect())