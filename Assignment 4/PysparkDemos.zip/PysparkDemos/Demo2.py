from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 2").master("local[*]").getOrCreate()

py_number_list = [1,2,3,4,5]
print(py_number_list, type(py_number_list))

number_rdd = spark.sparkContext.parallelize(py_number_list, 3) # here 3 is the number of partitions
print(type(number_rdd), number_rdd.collect())

py_str_list = ['Arun', 'Arwind', 'Arjun', 'Anna']
print(type(py_str_list), py_str_list)

str_rdd = spark.sparkContext.parallelize(py_str_list, 2)
print(type(str_rdd), str_rdd.collect())

# spark.stop()

# reading text file
# file_rdd = spark.sparkContext.textFile(<file path>)