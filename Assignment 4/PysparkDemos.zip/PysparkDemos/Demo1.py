from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 1").master("local[*]").getOrCreate()
print(spark)
print(spark.sparkContext)
print(dir(spark.sparkContext))
spark.stop()