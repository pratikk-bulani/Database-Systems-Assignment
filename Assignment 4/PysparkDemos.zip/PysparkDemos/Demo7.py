from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 7").master("local[*]").getOrCreate()

py_number_list_1 = [1,2,3,4,5]
py_number_list_2 = [6,7,8,9]
number_rdd_1 = spark.sparkContext.parallelize(py_number_list_1, 3)
number_rdd_2 = spark.sparkContext.parallelize(py_number_list_2, 3)

print(number_rdd_1.union(number_rdd_2).collect())