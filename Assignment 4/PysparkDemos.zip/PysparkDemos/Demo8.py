from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 8").master("local[*]").getOrCreate()

py_number_list_1 = [1,2,3,4,5]
py_number_list_2 = [6,7,3,8,9,1]
number_rdd_1 = spark.sparkContext.parallelize(py_number_list_1, 3)
number_rdd_2 = spark.sparkContext.parallelize(py_number_list_2, 3)

print(number_rdd_1.intersection(number_rdd_2).collect())