from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 13").master("local[*]").getOrCreate()

key_value_pair_list = [("CSK", 3), ("MI", 2), ("CSK", 2), ("MI", 3), ("RCB", 2), ("CSK", 3)]
key_value_pair_rdd = spark.sparkContext.parallelize(key_value_pair_list, 2)

print(key_value_pair_rdd.aggregateByKey(
    (0.0, 0), # this is the initialization parameter. Here 0th index will store the sum and 1st index will store the count i.e. multiple aggregate functions
    lambda init_param, value: (init_param[0] + value, init_param[1] + 1), # this is the sequence operation i.e. how to calculate the values of aggregate functions
    lambda rdd1, rdd2: (rdd1[0] + rdd2[0], rdd1[1] + rdd2[1]) # groups are created for each partition. This is the combining step i.e. same keys belonging to separate partitions are combined here
).collect())