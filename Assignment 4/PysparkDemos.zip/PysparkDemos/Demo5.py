from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 5").master("local[*]").getOrCreate()

py_string_number_list = ['1,2,3,4,5', '6,7,8,9,10', '11,12,13,14,15']
number_str_rdd = spark.sparkContext.parallelize(py_string_number_list, 3)
print(number_str_rdd.flatMap(lambda n: n.split(",")).collect()) # flattens the list