from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Demo 12").master("local[*]").getOrCreate()

py_number_list = [1,2,3,4,5, 3, 1, 2]
number_rdd = spark.sparkContext.parallelize(py_number_list, 3)

print(number_rdd.map(lambda n: (n, 1)).sortByKey().collect()) # here 0th index (key) is the original element and 1st index (value) is the element 1