#!/bin/bash
if [ "$#" -eq 2 ]; then
    python3 ./2019201074_1.py "$1" "$2"
elif [ "$#" -eq 1 ]; then
    python3 ./2019201074_2.py "$1"
fi