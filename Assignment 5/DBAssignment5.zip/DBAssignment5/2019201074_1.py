import sys
import re
from collections import OrderedDict

if(len(sys.argv) != 3): raise Exception("Error: Invalid number of command line arguments")
round_robin_value = int(sys.argv[2])
file_input = open(sys.argv[1], "r")
input_lines = file_input.readlines()
file_input.close()

disk_block = input_lines[0].replace("\n", "").strip().split()
disk_block_new = []
for i in range(0, len(disk_block), 2):
    disk_block_new.append([disk_block[i], int(disk_block[i+1])])
disk_block_new.sort()
disk_block = OrderedDict(disk_block_new)
del disk_block_new

main_memory_variables = OrderedDict([(k, None) for k in disk_block.keys()])

transaction_operations = OrderedDict(); i = 1; transaction_execution = OrderedDict(); available_transactions = []
while i < len(input_lines):
    if re.match(r"\s*\n", input_lines[i]):
        pass
    elif re.match(r"\s*[A-Za-z0-9]+\s+\d+\s*\n", input_lines[i]):
        transaction_name, total_operations = re.match(r"\s*([A-Za-z0-9]+)\s+(\d+)\s*\n", input_lines[i]).groups()
        transaction_operations[transaction_name] = []
        transaction_execution[transaction_name] = 0
        available_transactions.append(transaction_name)
        for j in range(int(total_operations)):
            transaction_operations[transaction_name].append(input_lines[i + j + 1].replace("\n","").strip())
        i += int(total_operations)
    i += 1
del input_lines

def write_log_record(log_record):
    file_output.write(log_record + "\n")
    for k, v in main_memory_variables.items():
        if v is not None:
            file_output.write(k + " " + str(v) + " ")
    file_output.write("\n")
    for k, v in disk_block.items():
        file_output.write(k + " " + str(v) + " ")
    file_output.write("\n")

temporary_variables = {}
def execute_transaction_operation(operation, transaction_name):
    if re.match(r"READ\s*[(]\s*(.+?)\s*,\s*(.+?)\s*[)]", operation):
        matched_pattern = re.match(r"READ\s*[(]\s*(.+?)\s*,\s*(.+?)\s*[)]", operation).groups()
        if main_memory_variables[matched_pattern[0]] is None:
            main_memory_variables[matched_pattern[0]] = disk_block[matched_pattern[0]]
        temporary_variables[matched_pattern[1]] = main_memory_variables[matched_pattern[0]]
    elif re.match(r"(.+?)\s*:=\s*(.+?)\s*([+]|[*]|-|/)\s*(\d+)", operation):
        matched_pattern = re.match(r"(.+?)\s*:=\s*(.+?)\s*([+]|[*]|-|/)\s*(\d+)", operation).groups()
        first_operand = temporary_variables[matched_pattern[1]]
        second_operand = int(matched_pattern[3])

        if matched_pattern[2] == "+":
            temporary_variables[matched_pattern[0]] = first_operand + second_operand
        elif matched_pattern[2] == "-":
            temporary_variables[matched_pattern[0]] = first_operand - second_operand
        elif matched_pattern[2] == "*":
            temporary_variables[matched_pattern[0]] = first_operand * second_operand
        else:
            temporary_variables[matched_pattern[0]] = first_operand // second_operand
    elif re.match(r"WRITE\s*[(]\s*(.+?)\s*,\s*(.+?)\s*[)]", operation):
        matched_pattern = re.match(r"WRITE\s*[(]\s*(.+?)\s*,\s*(.+?)\s*[)]", operation).groups()
        prev_value = main_memory_variables[matched_pattern[0]]
        main_memory_variables[matched_pattern[0]] = temporary_variables[matched_pattern[1]]
        write_log_record("<" + transaction_name + ", " + matched_pattern[0] + ", " + str(prev_value) + ">")
    elif re.match(r"OUTPUT\s*[(]\s*(.+?)\s*[)]", operation):
        matched_pattern = re.match(r"OUTPUT\s*[(]\s*(.+?)\s*[)]", operation).groups()
        disk_block[matched_pattern[0]] = main_memory_variables[matched_pattern[0]]
    else: raise Exception("Error: Invalid operation present")

no_of_completed_transactions = 0
index = 0
file_output = open("2019201074_1.txt", "w")
while True:
    transaction_name = available_transactions[index % len(available_transactions)]
    index += 1
    if no_of_completed_transactions == len(available_transactions):
        break
    if transaction_execution[transaction_name] == -1:
        continue
    if transaction_execution[transaction_name] == 0:
        write_log_record("<START " + transaction_name + ">")
    for operation in transaction_operations[transaction_name][transaction_execution[transaction_name]:transaction_execution[transaction_name]+round_robin_value]:
        execute_transaction_operation(operation, transaction_name)
    transaction_execution[transaction_name] += round_robin_value
    if transaction_execution[transaction_name] >= len(transaction_operations[transaction_name]):
        transaction_execution[transaction_name] = -1
        write_log_record("<COMMIT " + transaction_name + ">")
        no_of_completed_transactions += 1
    
del disk_block, main_memory_variables, temporary_variables
file_output.close()