import sys
import re
from collections import OrderedDict

if(len(sys.argv) != 2): raise Exception("Error: Invalid number of command line arguments")
file_input = open(sys.argv[1], "r")
input_lines = file_input.readlines()
file_input.close()
if not input_lines[-1].endswith("\n"): input_lines[-1] = input_lines[-1] + "\n"

disk_block = input_lines[0].replace("\n", "").strip().split()
disk_block_new = []
for i in range(0, len(disk_block), 2):
    disk_block_new.append([disk_block[i], disk_block[i+1]])
disk_block_new.sort()
disk_block = OrderedDict(disk_block_new)
del disk_block_new

completed_transactions = []; end_checkpoint = False; recover_transactions = []
for i in range(len(input_lines)-1, 1, -1):
    if re.match(r"\s*<\s*COMMIT\s+(.+?)\s*>\s*\n", input_lines[i]):
        completed_transactions.append(re.match(r"\s*<\s*COMMIT\s+(.+?)\s*>\s*\n", input_lines[i]).groups()[0])
    elif re.match(r"\s*<\s*ABORT\s+(.+?)\s*>\s*\n", input_lines[i]):
        completed_transactions.append(re.match(r"\s*<\s*ABORT\s+(.+?)\s*>\s*\n", input_lines[i]).groups()[0])
    elif re.match(r"\s*<\s*END\s+CKPT\s*>\s*\n", input_lines[i]):
        end_checkpoint = True
    elif re.match(r"\s*<\s*START\s+CKPT\s*[(]\s*(.+?)\s*[)]\s*>\s*\n", input_lines[i]):
        if end_checkpoint == True: break
        matched_pattern = re.match(r"\s*<\s*START\s+CKPT\s*[(]\s*(.+?)\s*[)]\s*>\s*\n", input_lines[i]).groups()
        checkpoint_lists = matched_pattern[0].split(",")
        checkpoint_lists = [c.strip() for c in checkpoint_lists]
        for transaction in checkpoint_lists:
            if transaction not in completed_transactions:
                recover_transactions.append(transaction)
        break
    elif re.match(r"\s*<\s*START\s+(.+?)\s*>\s*\n", input_lines[i]):
        matched_pattern = re.match(r"\s*<\s*START\s+(.+?)\s*>\s*\n", input_lines[i]).groups()
        if matched_pattern[0] not in completed_transactions:
            recover_transactions.append(matched_pattern[0])

transactions_completed_recovering = 0
for i in range(len(input_lines)-1, 1, -1):
    if transactions_completed_recovering == len(recover_transactions): break
    if re.match(r"\s*<\s*START\s+CKPT\s*[(]\s*(.+?)\s*[)]\s*>\s*\n", input_lines[i]):
        pass # do nothing. let it be present to save from the next elif clause.
    elif re.match(r"\s*<\s*START\s+(.+?)\s*>\s*\n", input_lines[i]):
        matched_pattern = re.match(r"\s*<\s*START\s+(.+?)\s*>\s*\n", input_lines[i]).groups()
        if matched_pattern[0] in recover_transactions:
            transactions_completed_recovering += 1
    elif re.match(r"\s*<\s*(.+?)\s*,\s*(.+?)\s*,\s*(.+?)\s*>\s*\n", input_lines[i]):
        matched_pattern = re.match(r"\s*<\s*(.+?)\s*,\s*(.+?)\s*,\s*(.+?)\s*>\s*\n", input_lines[i]).groups()
        if matched_pattern[0] in recover_transactions:
            disk_block[matched_pattern[1]] = matched_pattern[2]

file_output = open("2019201074 2.txt", "w")
for k, v in disk_block.items():
    file_output.write(k + " " + v + " ")
file_output.write("\n")
file_output.close()