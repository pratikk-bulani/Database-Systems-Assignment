import sqlparse
import re
import ClausesExecution
import sys

try:
    # Store the metadata in the dictionary
    dict_metadata = dict()
    file_metadata = open("metadata.txt", "r")
    table_name = ""
    while True:
        line_read = file_metadata.readline() # each line ends with '\n'
        if(line_read == ""):
            if(table_name == ""):
                break
            else:
                raise Exception("Invalid metadata format")
        
        if(line_read.lower().startswith("<begin_table>")):
            table_name = file_metadata.readline()
            if table_name.lower().startswith("<end_table>"):
                raise Exception("No table is present within the tag")
            elif table_name == "":
                raise Exception("Invalid metadata format")
            elif table_name.endswith("\n"):
                table_name = table_name[:-1]
            dict_metadata[table_name] = []
        
        elif(line_read.lower().startswith("<end_table>")):
            if(len(dict_metadata[table_name]) == 0):
                raise Exception("No columns are present in the table " + table_name)
            table_name = ""

        else:
            if table_name == "":
                raise Exception("Invalid metadata format")
            dict_metadata[table_name].append(line_read.replace("\n",""))
    file_metadata.close()

    # Store the tablular data in the dictionary
    dict_table = dict()
    for table_name, columns_list in dict_metadata.items():
        try:
            file_table_data = open(table_name+".csv", "r")
        except FileNotFoundError:
            raise Exception("Table " + table_name + ".csv is not present")

        dict_table[table_name.lower()] = []

        while True:
            table_data = file_table_data.readline()
            if(table_data == ""):
                break
            table_data = table_data.replace("\"","").replace("\'","").replace("\n","")

            table_data = table_data.split(",")
            if(len(table_data) != len(dict_metadata[table_name])):
                raise Exception("Number of data doesn't match the number of columns for the row " + table_data)

            dict_table[table_name.lower()].append(dict())

            for i in range(len(table_data)):
                dict_table[table_name.lower()][-1].update({dict_metadata[table_name][i].lower():int(table_data[i])})

        file_table_data.close()

    try:
        if(len(sys.argv) != 2):
            raise Exception("Invalid number of arguments in command line")
        user_input = sqlparse.format(sys.argv[1], encoding=None, reindent=False, keyword_case='upper', identifier_case='lower', strip_comments=True)
        user_input = sqlparse.split(user_input, encoding=None)

        for command in user_input:
            details_extraction = re.match(r"^\s*SELECT\s+(.+?)\s+FROM\s+(.+?)(\s+WHERE\s+(.+?))?\s*;*\s*$", command)
            if details_extraction is None:
                raise Exception("Invalid SELECT query format as per the assignment question")
            details_extraction = list(details_extraction.groups())
            details_extraction.pop(2)
            
            result1 = ClausesExecution.fromExecution(details_extraction[1], dict_table)
            result2 = ClausesExecution.whereExecution(details_extraction[2], result1)
            if len(result2) == 0:
                result2 = [{i:None for i in result1[0]}]
            ClausesExecution.selectExecution(details_extraction[0], result2, dict_metadata)
    except Exception as e:
        print("Error:", e)
except Exception as e:
    print("Error:", e)