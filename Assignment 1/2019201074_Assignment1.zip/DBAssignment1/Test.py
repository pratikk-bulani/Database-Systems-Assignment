import re
import sqlparse
import sys
print(sys.argv)
sql = "t.a >= 20 and t.b = 13"
r1 = sqlparse.parse(sql.strip())
print(r1[0].tokens)
# print(r1[0].tokens[2].ttype, r1[0].tokens[2])
# for i in r1[0].tokens[0].flatten():
#     print(i, i.ttype)

# a = [1, 2, 3]
# s = "lambda x: x[0]+x[1]+x[2]-1"
# print(s)
# f = eval(s)
# print(f(a))