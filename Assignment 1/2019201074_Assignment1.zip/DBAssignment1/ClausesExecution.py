import re
import sqlparse

def fromExecution(from_clause, dict_table):
    parsed_from_clause = sqlparse.parse(from_clause)
    if len(parsed_from_clause[0].tokens)!=1 or str(type(parsed_from_clause[0].tokens[0])).find("Identifier")==-1:
        raise Exception("Invalid construct of FROM clause")

    from_clause = []
    for i in parsed_from_clause[0].tokens[0].flatten():
        if str(i.ttype).find("Name")!=-1:
            if(str(i) in dict_table):
                from_clause.append(str(i))
            else:
                raise Exception("Table " + str(i) + " is not present in the database")
    
    result = [dict()]
    for table_name in from_clause:
        new_result = []
        for d1 in result:
            for d2 in dict_table[table_name]:
                d1_copy = d1.copy()
                for key, value in d2.items():
                    d1_copy[table_name+"."+key] = value
                new_result.append(d1_copy)
        del result
        result = new_result
    return result

def whereExecution(where_clause, dict_table):
    if where_clause == None:
        return dict_table
    
    parsed_where_clause = sqlparse.parse(where_clause)
    lambda_string = "lambda x:"
    relational_operators_map = {">=":" >=", "=":" ==", "<>":" !=", "<=":" <=", ">":" >", "<":" <"}
    columns = []
    variable_started = False
    i = 0

    for statement in parsed_where_clause[0].tokens:
        if str(type(statement)).find("Comparison") != -1:
            for token in statement.flatten():
                if str(token.ttype).find("Whitespace")!=-1:
                    variable_started = False
                    continue
                elif str(token.ttype).find("Operator.Comparison")!=-1:
                    variable_started = False
                    if str(token) in relational_operators_map:
                        lambda_string += relational_operators_map[str(token)]
                    else:
                        raise Exception("Invalid operator present in WHERE clause " + str(token))
                elif str(token.ttype).find("Punctuation")!=-1:
                    if str(token) == ".":
                        continue
                    else:
                        raise Exception("Invalid punctuation present in WHERE clause " + str(token))
                elif str(token.ttype).find("Literal.Number.Integer")!=-1:
                    lambda_string += " " + str(token)
                elif str(token.ttype).find("Name")!=-1:
                    if variable_started:
                        columns[-1] += "." + str(token)
                    else:
                        columns.append(str(token))
                        lambda_string += " x[" + str(i) + "]"
                        i += 1
                    variable_started = True
                else:
                    raise Exception("Invalid token in WHERE clause " + str(token))
        elif str(type(statement)).find("Token") != -1:
            variable_started = False
            if str(statement.ttype).find("Whitespace")!=-1:
                continue
            elif str(statement.ttype).find("Keyword")!=-1:
                if str(statement) == "AND":
                    lambda_string += " and"
                elif str(statement) == "OR":
                    lambda_string += " or"
                else:
                    raise Exception("Invalid keyword in WHERE clause" + str(statement))
            else:
                raise Exception("Invalid token in WHERE clause " + str(statement))
        else:
            raise Exception("Invalid statement in WHERE clause " + str(statement))
    
    try:
        lambda_function = eval(lambda_string)
    except:
        raise Exception("Invalid constuct of WHERE clause")
    result = []
    for i in range(len(columns)):
        columns[i] = fetchFullyQualifiedColumnName(columns[i], dict_table)
    for row in dict_table:
        columns_value = []
        for col in columns:
            columns_value.append(row[col])
        if lambda_function(columns_value):
            result.append(row)
    return result

def selectExecution(select_clause, dict_table, dict_metadata):
    parsed_select_clause = sqlparse.parse(select_clause)
    if (len(parsed_select_clause[0].tokens)!=1 or (str(type(parsed_select_clause[0].tokens[0])).find("Identifier")==-1 and str(type(parsed_select_clause[0].tokens[0])).find("Function")==-1)) and select_clause!="*":
        raise Exception("Invalid construct of SELECT clause")

    if re.match(r".*(sum|avg|min|max)\s*[(].+?[)].*", select_clause) is not None:
        selectAggregateExecution(select_clause, dict_table, dict_metadata)
    elif re.match(r".*distinct[(].*[)].*", select_clause) is not None:
        selectDistinctExecution(select_clause, dict_table, dict_metadata)
    else:
        selectNormalExecution(select_clause, dict_table, dict_metadata)

def aggregateSum(column_name, dict_table):
    if dict_table[0][column_name] is None:
        return
    result = 0
    for d in dict_table:
        result += d[column_name]
    return result

def aggregateMin(column_name, dict_table):
    if dict_table[0][column_name] is None:
        return
    result = 10000000000000000000000000000000000000000000
    for d in dict_table:
        if result > d[column_name]:
            result = d[column_name]
    return result

def aggregateMax(column_name, dict_table):
    if dict_table[0][column_name] is None:
        return
    result = -10000000000000000000000000000000000000000000
    for d in dict_table:
        if result < d[column_name]:
            result = d[column_name]
    return result

def aggregateAvg(column_name, dict_table):
    return aggregateSum(column_name, dict_table)/len(dict_table)

def displayRow(row):
    row = [str(i) for i in row if i != None]
    print(",".join(row))

def fetchFullyQualifiedColumnName(column_name, dict_table):
    if "." in column_name:
        if column_name in dict_table[0]:
            result = column_name
        else:
            raise Exception("Invalid column " + column_name)
    else:
        result = ""
        for key in dict_table[0]:
            if key.endswith(column_name):
                result += key
        if result == "":
            raise Exception("Invalid column " + column_name)
        elif result.count(".") > 1:
            raise Exception("Ambiguous column " + column_name)
    return result

def fetchCaseSensitiveColumnName(column_name, dict_metadata):
    for table_name, list_columns in dict_metadata.items():
        if column_name.startswith(table_name.lower() + "."):
            for column in list_columns:
                if column_name.endswith("." + column.lower()):
                    return table_name + "." + column

def selectAggregateExecution(select_clause, dict_table, dict_metadata):
    select_clause = select_clause.split(",")
    output_row1 = []
    output_row2 = []
    for column in select_clause:
        details_extraction = re.match(r"^\s*(sum|min|max|avg)\s*[(]\s*(.+?)\s*[)]\s*$", column)
        if details_extraction is None:
            raise Exception("Invalid construct of SELECT column " + str(column))
        details_extraction = list(details_extraction.groups())

        column_name = fetchFullyQualifiedColumnName(details_extraction[1], dict_table)
        output_row1.append(details_extraction[0]+"("+fetchCaseSensitiveColumnName(column_name,dict_metadata)+")")
        if details_extraction[0] == "sum":
            output_row2.append(aggregateSum(column_name, dict_table))
        elif details_extraction[0] == "min":
            output_row2.append(aggregateMin(column_name, dict_table))
        elif details_extraction[0] == "max":
            output_row2.append(aggregateMax(column_name, dict_table))
        elif details_extraction[0] == "avg":
            output_row2.append(aggregateAvg(column_name, dict_table))
        else:
            raise Exception("Invalid function " + details_extraction[0] + " present in SELECT clause")

    displayRow(output_row1)
    displayRow(output_row2)

def selectDistinctExecution(select_clause, dict_table, dict_metadata):
    if select_clause.count(",") > 1:
        raise Exception("Invalid query format as per the assignment question")
    details_extraction = re.match(r"^\s*distinct\s*[(]\s*(.+?)\s*[)]\s*$", select_clause)
    if details_extraction is None:
        raise Exception("Invalid construct of SELECT column " + str(select_clause))
    details_extraction = list(details_extraction.groups())

    column_name = fetchFullyQualifiedColumnName(details_extraction[0], dict_table)
    displayRow(["distinct("+fetchCaseSensitiveColumnName(column_name,dict_metadata)+")"])
    output = []
    for row in dict_table:
        if row[column_name] not in output:
            displayRow([row[column_name]])
            output.append(row[column_name])

def selectNormalExecution(select_clause, dict_table, dict_metadata):
    select_clause = [i.strip() for i in select_clause.split(",")]; new_select_clause = [];
    for i in select_clause:
        if i == "*":
            new_select_clause.extend(selectStarExecution(dict_table, dict_metadata))
        else:
            new_select_clause.append(fetchCaseSensitiveColumnName(fetchFullyQualifiedColumnName(i, dict_table), dict_metadata))
    displayRow(new_select_clause)

    for row in dict_table:
        result = []
        for column_name in new_select_clause:
            result.append(row[column_name.lower()])
        displayRow(result)

def selectStarExecution(dict_table, dict_metadata):
    select_clause = []
    for table_name, list_columns in dict_metadata.items():
        for column in list_columns:
            if str(table_name + "." + column).lower() in dict_table[0]:
                select_clause.append(fetchCaseSensitiveColumnName(str(table_name + "." + column).lower(), dict_metadata))
    return select_clause
