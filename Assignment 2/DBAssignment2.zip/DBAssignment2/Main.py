import re
import sys
import math
import threading
import time

try:
    '''The Start'''
    start_time = time.time()
    print("###start execution")

    '''
    Reading the metadata file and creating the regular expression to fetch the values of various columns
    '''
    try:
        file_metadata = open("Metadata.txt", "r")
    except FileNotFoundError:
        raise Exception("File Metadata.txt is not present in this folder")
    reg_ex = "^"
    # key = column and value = [index, number of bytes]
    dict_columns = dict()
    i = 0
    for line in file_metadata:
        if line == "" or line == "\n": break
        line = line.split(",")
        if len(line) != 2: raise Exception("Invalid Metadata format exception")
        elif line[0] in dict_columns: raise Exception("Column Name is repeated in metadata")
        elif line[-1].endswith("\n"): line[-1] = line[-1][:-1]
        try:
            dict_columns[line[0].lower()] = [i, int(line[1])]
            i += 1
            reg_ex += "(.{" + line[-1] + "})  "
        except: raise Exception("Invalid Metadata format exception")
    file_metadata.close()
    reg_ex = reg_ex[:-2] + "\n$"

    '''
    Parse the command line arguments
    '''
    if len(sys.argv) < 6: raise Exception("Invalid count of command line arguments")
    try:
        MAIN_MEMORY_BUFFER_SIZE = float(sys.argv[3]) * 2**20
        if sys.argv[4].lower() in ['asc', 'desc']:
            NUMBER_OF_THREADS = 0
            ASCENDING = True if sys.argv[4].lower() == 'asc' else False
            columns_start_index = 5
        else:
            NUMBER_OF_THREADS = int(sys.argv[4])
            if sys.argv[5].lower() in ['asc', 'desc']:
                ASCENDING = True if sys.argv[5].lower() == 'asc' else False
            else: raise Exception()
            columns_start_index = 6
    except: raise Exception("Invalid command line arguments")
    COLUMNS_SORT_INDEX = []
    for col in sys.argv[columns_start_index:]:
        if col.lower() in dict_columns:
            COLUMNS_SORT_INDEX.append(dict_columns[col.lower()][0])
        else: raise Exception("Invalid column " + col + " passed in command line argument")
    if len(COLUMNS_SORT_INDEX) == 0: raise Exception("No columns passed in command line argument")

    '''
    Configuring data (Phase 1)
    '''
    TUPLE_SIZE_BYTES = sum([dict_columns[i][1] for i in dict_columns])
    TOTAL_TUPLES_IN_BUFFER = int(MAIN_MEMORY_BUFFER_SIZE // TUPLE_SIZE_BYTES // 2 // (1 if NUMBER_OF_THREADS == 0 else 3)) # (1 if NUMBER_OF_THREADS == 0 else 3) to accomodate the thread working
    if TOTAL_TUPLES_IN_BUFFER < 1: raise Exception("Main memory buffer is not sufficient for phase 1")

    '''
    Lambda expresssion for sorting
    '''
    sort_lambda_string = "lambda x: ("
    for i in COLUMNS_SORT_INDEX:
        sort_lambda_string += ("x[" + str(i) + "], ")
    sort_lambda_string = sort_lambda_string[:-2] + ")"
    sort_lambda_function = eval(sort_lambda_string)

    '''
    Thread's work
    '''
    # sub_table = list holding all the records, total_tuples_sub_table = total records in sub_table (as sub_table can hold None records), sub_list_no = sublist file name
    def thread_work(sub_table, total_tuples_sub_table, sub_list_no):
        if len(sub_table) != total_tuples_sub_table:
            new_sub_table = sub_table[:total_tuples_sub_table]
            del sub_table; sub_table = new_sub_table
        print("sorting #" + str(sub_list_no) + " sublist")
        sub_table.sort(key = sort_lambda_function, reverse = not ASCENDING)
        print("Writing to disk #" + str(sub_list_no))
        file_sub_list = open("sub_list_"+str(sub_list_no)+".txt", "w")
        for i in sub_table:
            file_sub_list.write("  ".join(i) + "\n")
        file_sub_list.close()
        del sub_table

    '''
    Phase 1
    '''
    print("##running Phase-1")
    sub_table = [None]*TOTAL_TUPLES_IN_BUFFER
    try:
        file_input = open(sys.argv[1], "r")
    except FileNotFoundError:
        raise Exception("File " + sys.argv[1] + " is not present in this folder")
    i = 0; sub_list_no = 1; threads_list = []
    for line in file_input:
        if line == "" or line == "\n": break
        sub_table[i] = re.match(reg_ex, line).groups()
        if sub_table[i] is None: raise Exception("Invalid format for the row " + str(i+1))
        i += 1
        if i == len(sub_table):
            if NUMBER_OF_THREADS == 0:
                thread_work(sub_table, i, sub_list_no)
            else:
                threads_list.append(threading.Thread(target=thread_work, args=(sub_table, i, sub_list_no)))
                threads_list[-1].start()
            sub_table = [None]*TOTAL_TUPLES_IN_BUFFER; i=0; sub_list_no += 1
    file_input.close()
    if(sub_table[0] == None):
        sub_list_no -= 1
    else:
        thread_work(sub_table, i, sub_list_no)

    for t in threads_list:
        t.join()
        del t

    print("Total number of sub-files (splits):", sub_list_no)

    '''
    Configuring data (Phase 2)
    '''
    TOTAL_TUPLES_PER_SUB_LIST = int(MAIN_MEMORY_BUFFER_SIZE // (sub_list_no + 3) // TUPLE_SIZE_BYTES // 2) # Intentionally made it (sub_list_no + 3). Earlier it was (sub_list_no + 2).
    if TOTAL_TUPLES_PER_SUB_LIST < 1: raise Exception("Main memory buffer is not sufficient for phase 2")
    output_list = [None] * TOTAL_TUPLES_PER_SUB_LIST; j=0
    # sub_files_list = each element stores information about the sub list [file descriptor, index position, list storing records]
    sub_files_list = []
    for i in range(sub_list_no):
        sub_files_list.append(list())
    for i in range(1,sub_list_no+1):
        sub_files_list[i-1].extend([open("sub_list_"+str(i)+".txt", "r"), 0, None])

    '''
    Refill the sublist which got completed
    '''
    def refill(sub_files_list_element):
        sub_files_list_element[1] = 0
        sub_files_list_element[2] = [None]*TOTAL_TUPLES_PER_SUB_LIST
        i = 0
        for line in sub_files_list_element[0]:
            if line == "" or line == "\n": break
            sub_files_list_element[2][i] = re.match(reg_ex, line).groups()
            i += 1
            if i == TOTAL_TUPLES_PER_SUB_LIST: break

    '''
    Fill the sublist data initially
    '''
    for sub_files_list_element in sub_files_list:
        refill(sub_files_list_element)

    # I have decided to create heap list as list of [indexed record of a sorted sublist, index position of the sub_files_list from where the recod is taken]
    '''
    Creating new lambda function
    '''
    sort_lambda_function = eval("lambda x: " + sort_lambda_string[sort_lambda_string.index(":")+1:].replace("x","x[0]"))

    '''
    Phase 2
    '''
    print("##running phase-2")
    print("Sorting...")
    print("Writing to disk")
    file_output = open(sys.argv[2], "w")
    heap_list = [[sub_files_list[i][2][sub_files_list[i][1]], i] for i in range(len(sub_files_list)) if sub_files_list[i][2][sub_files_list[i][1]] is not None]
    while len(heap_list)!=0:
        heap_list.sort(key = sort_lambda_function, reverse = not ASCENDING)
        output_list[j] = heap_list[0][0]; j += 1
        sub_files_list[heap_list[0][1]][1] += 1
        if j == TOTAL_TUPLES_PER_SUB_LIST:
            for i in output_list:
                file_output.write("  ".join(i) + "\n")
            del output_list; output_list = [None] * TOTAL_TUPLES_PER_SUB_LIST; j=0
        if sub_files_list[heap_list[0][1]][1] == TOTAL_TUPLES_PER_SUB_LIST:
            refill(sub_files_list[heap_list[0][1]])
        del heap_list
        heap_list = [[sub_files_list[i][2][sub_files_list[i][1]], i] for i in range(len(sub_files_list)) if sub_files_list[i][2][sub_files_list[i][1]] is not None]
    for i in output_list:
        if i is None: break
        file_output.write("  ".join(i) + "\n")

    del heap_list, output_list

    for i in range(sub_list_no):
        sub_files_list[i][0].close()
    file_output.close()

    '''The End'''
    print("--- %s seconds ---" % (time.time() - start_time))
    print("###completed execution")
except Exception as e:
    print("Error:", str(e))
