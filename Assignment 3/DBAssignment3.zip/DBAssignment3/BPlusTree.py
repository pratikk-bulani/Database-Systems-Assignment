class BPlusNode:
    def __init__(self, is_leaf = True, order = 3):
        self.order = order
        self.is_leaf = is_leaf
        self.is_root = False
        self.keys = []
        if self.is_leaf:
            self.right_sibling_pointer = None
            self.left_sibling_pointer = None
        else:
            self.child_pointer = []
    def insert(self, item):
        if self.is_leaf:
            # check if the item is already present
            for key in self.keys:
                if key[0] == item:
                    key[1] += 1
                    return self

            if len(self.keys) == self.order - 1:
                # overflow condition
                return BPlusNode.__split_leaf_node(self, item)
            else:
                # not yet overflown. just add the item to the leaf node in ascending order.
                self.keys.append([item, 1]); self.keys.sort(); return self
        else:
            # look for the next level node where the item needs to be inserted
            child_pointer_index = BPlusNode.__next_level_child_node_index(self.keys, item)
            result_returned = self.child_pointer[child_pointer_index].insert(item) # the returned result can be either a single node or tuple of two nodes

            # modify the current node based on the result from child node
            if isinstance(result_returned, BPlusNode): self.child_pointer[child_pointer_index] = result_returned; return self
            elif isinstance(result_returned, tuple):
                if len(self.keys) == self.order - 1:
                    # overflow condition
                    return_result = BPlusNode.__split_internal_node(self, child_pointer_index, result_returned)
                    if(result_returned[1].is_leaf == False): result_returned[1].keys.pop(0)
                    return return_result
                else:
                    # not yet overflown. just add the item to the keys of internal node in ascending order.
                    if result_returned[1].is_leaf:
                        self.keys.insert(child_pointer_index, result_returned[1].keys[0][0])
                    else:
                        self.keys.insert(child_pointer_index, result_returned[1].keys[0])
                    if(result_returned[1].is_leaf == False): result_returned[1].keys.pop(0)
                    
                    # modify the child pointers as well
                    self.child_pointer[child_pointer_index] = result_returned[0]
                    self.child_pointer.insert(child_pointer_index+1, result_returned[1])
                    
                    return self
            raise Exception("Error: Some error occurred due to unknown reasons") # this statement should not be reached ideally
    def range(self, item1, item2):
        if item2 < item1: raise Exception("Error: Invalid range")
        
        temp = self
        while not temp.is_leaf:
            child_pointer_index = BPlusNode.__next_level_child_node_index(temp.keys, item1)
            temp = temp.child_pointer[child_pointer_index]
        count = 0
        while True:
            if temp is None: return count
            for key in temp.keys:
                if key[0] >= item1 and key[0] <= item2:
                    count += key[1]
                elif key[0] > item2:
                    return count
            temp = temp.right_sibling_pointer
        raise Exception("Error: Some error occurred due to unknown reasons") # this statement should not be reached ideally
    def find(self, item):
        if self.range(item, item) > 0: return "YES"
        else: return "NO"
    def count(self, item):
        return self.range(item, item)
    def print_leaves(self):
        temp = self
        while(not temp.is_leaf):
            temp = temp.child_pointer[0]
        count_unique = 0
        count_total = 0
        while temp:
            print(temp.keys)
            count_unique += len(temp.keys)
            for key in temp.keys:
                count_total += key[1]
            temp = temp.right_sibling_pointer
        print("Total unique elements in the B+ tree:", count_unique)
        print("Total elements in the B+ tree:", count_total)
    @staticmethod
    def __next_level_child_node_index(keys_list, item):
        if item < keys_list[0]: return 0
        elif item >= keys_list[-1]: return len(keys_list)
        else:
            for i in range(len(keys_list)-1):
                if item >= keys_list[i] and item < keys_list[i+1]:
                    return i+1
        raise Exception("Error: Some error occurred due to unknown reasons") # this statement should not be reached ideally
    @staticmethod
    def __split_leaf_node(leaf_node, item_inserted):
        # add the item to a temp new_keys list
        new_keys = leaf_node.keys + [[item_inserted, 1]]; new_keys.sort()

        # nodes creation
        left_node = BPlusNode(); right_node = BPlusNode()
        left_node.keys = new_keys[:len(new_keys)//2]; right_node.keys = new_keys[len(new_keys)//2:]

        # change of pointers
        # pointers in between the left and right nodes
        left_node.right_sibling_pointer = right_node; right_node.left_sibling_pointer = left_node
        # pointers from the left and right nodes to the outside world
        left_node.left_sibling_pointer = leaf_node.left_sibling_pointer; right_node.right_sibling_pointer = leaf_node.right_sibling_pointer
        # pointers from the outside world to these left and right nodes
        if leaf_node.left_sibling_pointer is not None:
            leaf_node.left_sibling_pointer.right_sibling_pointer = left_node
        if leaf_node.right_sibling_pointer is not None:
            leaf_node.right_sibling_pointer.left_sibling_pointer = right_node

        del new_keys # save space

        # new parent_node requirement
        if leaf_node.is_root:
            parent_node = BPlusNode(is_leaf = False); parent_node.is_root = True; parent_node.keys = [right_node.keys[0][0]]

            # pointers from the parent
            parent_node.child_pointer.extend([left_node, right_node])

            return parent_node
        
        return left_node, right_node
    @staticmethod
    def __split_internal_node(internal_node, child_pointer_index, result_returned):
        # add the item to a temp new_keys and new_child list
        new_keys = internal_node.keys.copy()
        if result_returned[1].is_leaf:
            new_keys.insert(child_pointer_index, result_returned[1].keys[0][0])
        else:
            new_keys.insert(child_pointer_index, result_returned[1].keys[0])
        new_child = internal_node.child_pointer.copy(); new_child[child_pointer_index] = result_returned[0]; new_child.insert(child_pointer_index+1, result_returned[1])
        
        # nodes creation
        left_node = BPlusNode(is_leaf = False); right_node = BPlusNode(is_leaf = False)
        left_node.keys = new_keys[:len(new_keys)//2]; right_node.keys = new_keys[len(new_keys)//2:]
        left_node.child_pointer = new_child[:len(new_keys)//2+1]; right_node.child_pointer = new_child[len(new_keys)//2+1:]

        del new_keys, new_child # save space

        # new parent_node requirement
        if internal_node.is_root:
            parent_node = BPlusNode(is_leaf = False); parent_node.is_root = True; parent_node.keys = [right_node.keys[0]]; right_node.keys.pop(0)

            # pointers from the parent
            parent_node.child_pointer.extend([left_node, right_node])

            return parent_node
        
        return left_node, right_node