import sys
from BPlusTree import BPlusNode
import re
try:
    bpt_object = BPlusNode(); bpt_object.is_root = True

    if len(sys.argv) != 2:
        raise Exception("Error: File name is not passed")

    command_file = open(sys.argv[1], "r")
    for command in command_file:
        if command.strip() == "" or command.strip() == "\n": break
        elif not command.endswith("\n"): command = command + "\n"

        if command.lower().startswith("insert"):
            inter_command = re.match(r"\s+(-?\d+)\s*\n", command[6:])
            if inter_command is None:
                raise Exception("Invalid command present in the file")
            
            bpt_object = bpt_object.insert(int(inter_command.groups()[0]))
        elif command.lower().startswith("find"):
            inter_command = re.match(r"\s+(-?\d+)\s*\n", command[4:])
            if inter_command is None:
                raise Exception("Invalid command present in the file")
            
            print(bpt_object.find(int(inter_command.groups()[0])))
        elif command.lower().startswith("count"):
            inter_command = re.match(r"\s+(-?\d+)\s*\n", command[5:])
            if inter_command is None:
                raise Exception("Invalid command present in the file")
            
            print(bpt_object.count(int(inter_command.groups()[0])))
        elif command.lower().startswith("range"):
            inter_command = re.match(r"\s+(-?\d+)\s+(-?\d+)\s*\n", command[5:])
            if inter_command is None:
                raise Exception("Invalid command present in the file")
            
            print(bpt_object.range(int(inter_command.groups()[0]), int(inter_command.groups()[1])))
        else:
            raise Exception("Error: Invalid command present in the file")
    command_file.close()
except Exception as e:
    print(e)