import random
for i in range(100):
    print("insert", random.randrange(-1000, 1000))

# list_1 = [[123, 2], [102, 100003], [120, 345555]]
# list_1.sort()
# print(list_1)